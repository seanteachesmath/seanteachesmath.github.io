line art gallery
================

<img src="line-art-gallery_files/figure-gfm/wagner-1.png" width="100%" style="display: block; margin: auto;" />
<!-- \vfill \newpage \vfill -->

<img src="line-art-gallery_files/figure-gfm/helton-1.png" width="100%" style="display: block; margin: auto;" />
<!-- \vfill \newpage \vfill -->

<img src="line-art-gallery_files/figure-gfm/evans-1.png" width="100%" style="display: block; margin: auto;" />
<!-- \vfill \newpage \vfill -->

<img src="line-art-gallery_files/figure-gfm/inori-1.png" width="100%" style="display: block; margin: auto;" />
<!-- \vfill \newpage \vfill -->

<img src="line-art-gallery_files/figure-gfm/wood-1.png" width="100%" style="display: block; margin: auto;" />
<!-- \vfill \newpage \vfill -->

<img src="line-art-gallery_files/figure-gfm/doughty-1.png" width="100%" style="display: block; margin: auto;" />
<!-- \vfill \newpage \vfill -->

<img src="line-art-gallery_files/figure-gfm/morgan-1.png" width="100%" style="display: block; margin: auto;" />
<!-- \vfill \newpage \vfill -->

<img src="line-art-gallery_files/figure-gfm/le-1.png" width="100%" style="display: block; margin: auto;" />
<!-- \vfill \newpage \vfill -->

<img src="line-art-gallery_files/figure-gfm/ammerman-1.png" width="100%" style="display: block; margin: auto;" />
<!-- \vfill \newpage \vfill -->

<img src="line-art-gallery_files/figure-gfm/powell-1.png" width="100%" style="display: block; margin: auto;" />
<!-- \vfill \newpage \vfill -->

<img src="line-art-gallery_files/figure-gfm/jawaid-1.png" width="100%" style="display: block; margin: auto;" />
<!-- \vfill \newpage \vfill -->

<img src="line-art-gallery_files/figure-gfm/will-1.png" width="100%" style="display: block; margin: auto;" />
<!-- \vfill \newpage \vfill -->

<img src="line-art-gallery_files/figure-gfm/wong-1.png" width="100%" style="display: block; margin: auto;" />
